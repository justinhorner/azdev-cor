﻿using System;
namespace Xamarin.Forms.Core
{
    public interface IFileViewer
    {
        void OpenFile(string filePath);
    }
}
