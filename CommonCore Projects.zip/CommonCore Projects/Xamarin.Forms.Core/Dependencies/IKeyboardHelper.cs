﻿using System;
namespace Xamarin.Forms.Core
{
    public interface IKeyboardHelper
    {
		void HideKeyboard();
	}
}
