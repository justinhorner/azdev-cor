﻿using System;
namespace Xamarin.Forms.Core
{
	public interface IBlurOverlay
	{
		void Hide();
		void Show();
	}
}
