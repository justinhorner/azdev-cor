﻿using System;
namespace Xamarin.Forms.Core
{
    public interface IViewStack
    {
        void DismissTopView();
    }
}
