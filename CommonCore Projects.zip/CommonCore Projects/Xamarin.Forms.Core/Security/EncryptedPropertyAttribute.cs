﻿using System;
namespace Xamarin.Forms.Core
{
    [AttributeUsage(AttributeTargets.Property)]
    public class EncryptedPropertyAttribute : Attribute { }

}
