﻿using System;
namespace Xamarin.Forms.Core
{
    public partial class CoreStyles
    {
        public static string OverlayColor { get; set; } = "#000000";
        public static float OverlayOpacity { get; set; } = 0.85f;
        	
    }
}
