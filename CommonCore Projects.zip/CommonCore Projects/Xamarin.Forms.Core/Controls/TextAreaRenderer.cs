﻿using System;
using Xamarin.Forms;

namespace Common.Core
{
    public class TextArea : Label
    {

    }
}

