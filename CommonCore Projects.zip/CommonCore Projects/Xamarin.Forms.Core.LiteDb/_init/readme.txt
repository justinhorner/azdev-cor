﻿Required Nuget Installs
 - LiteDB

 Step 1:
    Add the following settings to the json configuration
      "LiteliteSettings": {
        "LiteDatabase": "app.db"
      },

